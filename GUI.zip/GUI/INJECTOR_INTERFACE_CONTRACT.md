# Fault Injection Interface Contract

**Orchestrator (Python/GUI) ⇆ Injector (C++)** · v0.1 · draft for review

This document defines the two JSON interfaces between the orchestrator and the
injector, plus how the orchestrator launches the injector. Both sides build
against this contract.

- **Input** — `config.json`, written by the orchestrator, **read by the injector**. (This is the "our format is your input" part.)
- **Output** — `result.json`, written by the injector, **read by the orchestrator**.
- **Invocation** — the command line and process behaviour the orchestrator relies on.

The two payloads are deliberately symmetric: the output is the input with an
`id` and a `result` added per fault. Read the list, inject each entry, write the
list back with the verdict filled in.

---

## 1. Invocation

The orchestrator launches the injector as a child process, headless (no terminal).
Process model (no separate GDB process — OpenOCD is the debugger):

  * **Tiva (hardware):** the orchestrator opens **OpenOCD first**, then the injector.
    The injector must not be started until OpenOCD is up; it connects to OpenOCD.
  * **QEMU (emulation):** the orchestrator opens **only the injector**. The
    **injector launches QEMU itself** (its own process), using the per-fault `trigger` / `pc_trigger` / `timeout` fields below.

```
<injector> <config.json> <result.json>
```

| Arg | Meaning |
| --- | --- |
| `argv[1]` | Path to the input JSON the injector must read. |
| `argv[2]` | Path the injector must write the result JSON to. |

Two positional arguments — no flags. The backend, port and timeout come from the JSON `meta`, not the CLI.

Process behaviour the orchestrator depends on:

- **stdout** — optional progress lines for the live monitor (see §4). If you emit nothing, the monitor simply fills in once at the end.
- **stderr** — free‑form diagnostics. The orchestrator surfaces these as log lines; they do not need to be JSON.
- **Exit code** — `0` means the campaign ran to completion. A fault whose `result` is `FAIL` is a **normal, successful outcome** (the injector did its job) and must **not** cause a non‑zero exit. Reserve non‑zero exit codes for infrastructure failures only (cannot connect to the port, bad config, target unreachable).
- The injector reads `argv[1]`, performs every fault in order, writes `argv[2]`, then exits.

---

## 2. Input — orchestrator → injector

```json
{
  "meta": {
    "firmware": "cruise.elf",
    "mode": "qemu",
    "target": "ARM",
    "asil_level": "ASIL-D",
    "machine": "lm3s6965evb",
    "cpu": "cortex-m4",
    "server_port": 9001,
    "timeout_secs": 60
  },
  "faults": [
    {
      "id": 1,
      "fault_type": "sensor_corruption",
      "variable": "speed_RPM",
      "address": "",
      "system_state": "cruise_active",
      "value": 30,
      "min": 0,
      "max": 2,
      "duration_ms": 3500,
      "interval_ms": 50,
      "delay_ms": 10,
      "bit_position": 0,
      "trigger": "mem_access",
      "pc_trigger": "0x00000400",
      "timeout": 60
    }
  ]
}
```

### `meta` (campaign‑level, applies to every fault)

| Field | Type | Meaning |
| --- | --- | --- |
| `firmware` | string | ELF the target is running. |
| `mode` | string | `qemu` (emulation) or `hardware` (Tiva). The injector branches on this. |
| `target` | string | Architecture, currently `ARM`. |
| `asil_level` | string | `ASIL-A` … `ASIL-D`. Drives the orchestrator's pass/fail thresholds, not the injection. |
| `machine` | string | Target board / QEMU machine, e.g. `lm3s6965evb`. User-selected in the UI. |
| `cpu` | string | CPU core, e.g. `cortex-m4` / `cortex-m3`. User-selected in the UI. |
| `server_port` | int | TCP port the injector's plugin server binds (localhost). User-selected (3333 / 4444 / 1234 / 9001). |
| `timeout_secs` | int | QEMU session timeout in seconds (the injector's `QemuSessionConfig`). |
| `firmware` | string | **Bare ELF filename** (e.g. `cruise.elf`); the injector prepends its own ELF directory. Do not send a full path. |

### `faults[]` (one object per injection)

| Field | Type | Meaning |
| --- | --- | --- |
| `id` | int | Unique injection id (1‑based). |
| `fault_type` | string | One of `sensor_corruption`, `memory_corruption`, `bit_flip`, `set_pc`, `instruction_skip` (the injector's `kFaultTypeMap`). The GUI's "PC Error" is sent as `set_pc`, "Task Delay" as `instruction_skip`. |
| `variable` | string | Symbol to inject into, e.g. `speed_RPM` (resolved via `nm` → `inject_addr`). Empty for `set_pc`. |
| `address` | string | **Symbol name** for `set_pc` (resolved via `arm-none-eabi-nm` on the ELF), e.g. `cruise_loop`. **Not a hex address.** Empty for other types. |
| `system_state` | string | Symbol to monitor for the safe state (resolved via `nm` → `sensor_addr`). Available for all types; empty when unused. |
| `value` | int | Value written for corruption faults (→ `injected_value`, uint8). |
| `min` | int | Low end of the variable's valid range (for context / verdict). |
| `max` | int | High end of the valid range. |
| `duration_ms` | int | How long to keep injecting the fault, in ms. Must exceed the firmware's own fault‑reaction threshold or the system never reacts (see sizing note). |
| `interval_ms` | int | How often to re‑inject during the hold window, in ms. Must be smaller than the firmware's sampling period so re‑injection beats any ISR that overwrites the value. |
| `delay_ms` | int | Read by the injector as `target_count` (the instruction-count trigger). Only used when `trigger == "insn_count"`; ignored for `pc` / `mem_access` triggers. |
| `bit_position` | int | Bit to flip when `fault_type == "bit_flip"`; ignored otherwise. |
| `trigger` | string | **Required.** `mem_access` / `insn_count` / `pc` (the injector's `kTriggerMap`). |
| `pc_trigger` | string | Present for the GUI; the injector does not read it (it derives the PC from `address`). |

> **Varied campaigns:** the `faults[]` entries may be identical (same fault ×N) or distinct (a user-built list repeated to reach N). Either way each entry is self-contained and processed independently by `id`; the shape is unchanged.

> **Per‑type field use** (per the injector's `FaultConfig.h`): `memory_corruption` → `address`+`variable`+`value`+`min`/`max`; `instruction_skip` → `address`+`variable`; `bit_flip` → `delay_ms`(count)+`variable`+`bit_position`+`min`/`max`; `set_pc` → `delay_ms`(count)+`address`; `sensor_corruption` → `system_state`+`variable`+`value`+`min`/`max`. Unused fields are still present.

> **Sizing `duration_ms` / `interval_ms` (firmware‑specific).** These must be
> matched to the firmware under test, not guessed. `duration_ms` has to outlast
> the firmware's own fault‑reaction logic — e.g. if the cancel path needs N
> consecutive bad samples at a sampling period P, the hold must exceed `N × P`
> (give margin on top). `interval_ms` has to be shorter than that sampling
> period P so the injected value is re‑applied before the task samples it, even
> when an ISR is concurrently writing the real value. Example: a cancel path of
> 30 samples at 100 ms needs `duration_ms > 3000` (use ~3500) and
> `interval_ms ≈ 50` (re‑inject twice per 100 ms window).

> Field‑name note: these map 1:1 to the orchestrator's internal config
> (`min` ← `min_value`, `max` ← `max_value`, `value` ← `fault_value`). The
> orchestrator renames them on the way out so your input is clean.

---

## 3. Output — injector → orchestrator

Same shape as the input, with `id` + `result` guaranteed on every fault.

```json
{
  "meta": {
    "firmware": "cruise.elf",
    "mode": "qemu",
    "target": "ARM",
    "asil_level": "ASIL-D",
    "overhead_pct": 3.2
  },
  "faults": [
    {
      "id": 1,
      "fault_type": "sensor_corruption",
      "variable": "speed_RPM",
      "value": 30,
      "min": 0,
      "max": 2,
      "result": "FAIL",
      "note": "cruise control did not disengage"
    }
  ]
}
```

### Required per fault

| Field | Type | Meaning |
| --- | --- | --- |
| `id` | int | Matches the input `id`. |
| `result` | string | Verdict — one of `PASS` / `FAIL` / `ERROR`. See semantics below. |

Echoing the input fields (`fault_type`, `variable`, `value`, `min`, `max`) is
recommended so each result row is self‑describing.

### `result` semantics — read this carefully

| Value | Meaning | Counts as |
| --- | --- | --- |
| `PASS` | The system **handled** the fault and reached its safe state (e.g. cruise control disengaged). The safe / intended outcome. | success |
| `FAIL` | The fault **propagated** — the system did not mitigate it (unsafe). This is the dangerous case the campaign exists to catch. | failure |
| `ERROR` | The injection could **not be performed** (bad address, target lost). Excluded from pass/fail statistics. | neither |

This is the one place ambiguity would invert the entire report, so it is fixed
by the contract: **`PASS` = system safe, `FAIL` = system unsafe.** Your current
`"FAILED"` should map to `FAIL` only if it means "the system did not handle the
fault." If your `FAILED` currently means something else, flag it — do not silently map it.

### Optional per fault (enables the richer verdict)

| Field | Type | Effect if present |
| --- | --- | --- |
| `note` | string | Free text shown verbatim in the results table's "system response" column. |

> The injector does **not** send `reaction_ms` or `detected`. It cannot measure an exact reaction time; it compares recovery time to `delay_ms` (the ASIL deadline) and a late recovery is simply reported as `FAIL`. Lateness therefore shows up in the handling rate, not as a separate field.

### Optional `meta`

| Field | Type | Meaning |
| --- | --- | --- |
| `overhead_pct` | number | Measured runtime overhead of the safety mechanism (%). Feeds the overhead criterion. |

---

## 4. Optional live progress (stdout)

If you want the GUI's Live Monitor to tick per injection instead of filling in
at the end, print one line of JSON per event to stdout as you go:

```
{"type": "progress", "id": 1, "total": 30}
{"type": "log", "message": "halting target, writing 0x20000008"}
```

These are optional and independent of the `--out` file, which remains the
source of truth.

---

## 5. Deltas from your current output

Your sample:

```json
{ "faults": [ { "Firmware": "cruise.elf", "Mode": "qemu", "Target": "ARM",
                "address": "0x20000008", "fault_type": "memory_corruption",
                "id": 1, "max": 2, "min": 0, "result": "FAILED", "value": 255 } ] }
```

To conform:

1. Lower‑case the three capitalised keys (`Firmware` → `firmware`, `Mode` → `mode`, `Target` → `target`) and move them into a top‑level `meta` block.
2. Change `result` values to the `PASS` / `FAIL` / `ERROR` enum (your `FAILED` → `FAIL`, assuming it means "system did not handle it").
3. Carry `variable` (the variable name) instead of a hex `address`; everything else (`id`, `fault_type`, `value`, `min`, `max`) already matches.

Optional but recommended: add `overhead_pct` in `meta` so the ISO 26262 verdict
includes runtime overhead, not just the pass/fail count.

---

## 6. What changes on the orchestrator side (for our reference)

- Add `firmware` to `FaultConfig` and derive `mode`/`target` from the backend.
- Add an input serializer that emits the §2 shape (renaming `min_value`/`max_value`/`fault_value` → `min`/`max`/`value`).
- Add an output reader that parses the §3 shape and maps `result` → outcome (PASS/FAIL/ERROR); no reaction time is expected.
- The mock injector stays the default fallback, so the demo runs with no hardware.
